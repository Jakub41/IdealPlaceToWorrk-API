import shopifyController from './shopifyController';

export default { ShopCtrl: shopifyController };
